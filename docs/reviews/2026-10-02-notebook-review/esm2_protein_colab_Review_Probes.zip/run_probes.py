"""Probes for the Framework v1 review of esm2-protein-pipeline tutorials/esm2_protein_colab.ipynb (row 24).

CPU-only direct execution. Usage:
    python run_probes.py <notebook.ipynb> <run_dir>
<run_dir>/weights/esm2-t30-150m-ur50d/ is pre-seeded with the six manifest files from a local verified snapshot
(the notebook's verify_snapshot re-hashes them); staging from the Hub is therefore NOT exercised here.
The install step is skipped through the notebook's own hook DIMER_NOTEBOOK_CI_PREINSTALLED=1.
Cells run in one shared namespace, like a kernel. BYOD uploads go through a google.colab shim.
"""
import contextlib
import io
import json
import os
import random
import re
import sys
import time
import traceback
import types
from pathlib import Path

NB_PATH = Path(sys.argv[1]).resolve()
RUN_DIR = Path(sys.argv[2]).resolve()
OUT = Path(__file__).resolve().parent / 'results.json'
os.environ['DIMER_NOTEBOOK_CI_PREINSTALLED'] = '1'
os.environ['CUDA_VISIBLE_DEVICES'] = '-1'
os.chdir(RUN_DIR)

nb = json.loads(NB_PATH.read_text(encoding='utf-8'))
CELLS = nb['cells']
results = {'notebook': str(NB_PATH), 'run_dir': str(RUN_DIR), 'probes': {}}


def save():
    OUT.write_text(json.dumps(results, indent=2, default=str), encoding='utf-8')


# --- google.colab shim ------------------------------------------------------------------------
UPLOAD = {}
google = sys.modules.get('google') or types.ModuleType('google')
colab = types.ModuleType('google.colab')
colab.files = types.SimpleNamespace(upload=lambda: dict(UPLOAD))
google.colab = colab
sys.modules['google'] = google
sys.modules['google.colab'] = colab

NS = {'__name__': '__main__'}


def src(i, overrides=None):
    s = ''.join(CELLS[i]['source'])
    for name, value in (overrides or {}).items():
        s, n = re.subn(rf'^{name} = .*$', f'{name} = {value!r}  # probe override', s, count=1, flags=re.M)
        if n != 1:
            raise KeyError(f'field {name} not found in cell {i}')
    return s


def run(i, overrides=None):
    buf = io.StringIO()
    t0 = time.perf_counter()
    err = None
    with contextlib.redirect_stdout(buf), contextlib.redirect_stderr(buf):
        try:
            exec(compile(src(i, overrides), f'<cell {i}>', 'exec'), NS)
        except BaseException as exc:  # noqa: BLE001
            err = f'{type(exc).__name__}: {exc}'
            buf.write(traceback.format_exc(limit=2))
    out = buf.getvalue()
    return {'cell': i, 'seconds': round(time.perf_counter() - t0, 1), 'error': err, 'stdout_tail': out[-1500:]}


CODE = [i for i, c in enumerate(CELLS) if c['cell_type'] == 'code']

# --- P0 static -----------------------------------------------------------------------------------
p0 = {'code_cells': CODE, 'n_code': len(CODE), 'compile_errors': [], 'markers': []}
for i in CODE:
    s = ''.join(CELLS[i]['source'])
    try:
        compile(s, f'<cell {i}>', 'exec')
    except SyntaxError as exc:
        p0['compile_errors'].append(f'{i}: {exc}')
    for m in re.findall(r'\b(TODO|TBD|FIXME|WRITE ME)\b', s):
        p0['markers'].append((i, m))
    if CELLS[i].get('outputs') or CELLS[i].get('execution_count'):
        p0.setdefault('persisted_outputs', []).append(i)
md = '\n'.join(''.join(c['source']) for c in CELLS if c['cell_type'] == 'markdown')
p0['guided_layer_terms'] = {t: bool(re.search(t, md, re.I)) for t in [
    'how to use', 'roadmap', 'glossary', 'predict', 'check your', 'troubleshoot', 'infrastructure',
    'what to notice', 'look for', 'intended learner|audience', 'conclusion']}
p0['cellView_form'] = [i for i in CODE if CELLS[i].get('metadata', {}).get('cellView') == 'form']
p0['carried_chars'] = {i: len(''.join(CELLS[i]['source'])) for i in (5, 7, 9)}
p0['byod_location_field'] = bool(re.search(r'BYOD_PATH|_PATH = .*@param', src(13)))
p0['install_cell_uses_uv'] = 'uv ' in src(3) or "'uv'" in src(3)
results['probes']['P0_static'] = p0
save()

# --- P1 default path -------------------------------------------------------------------------------
p1 = {'cells': []}
t0 = time.perf_counter()
for i in CODE:
    r = run(i)
    p1['cells'].append(r)
    if r['error']:
        break
p1['total_seconds'] = round(time.perf_counter() - t0, 1)
p1['completed'] = sum(1 for c in p1['cells'] if not c['error'])
if 'test_metrics' in NS:
    tm = NS['test_metrics']
    p1['test'] = {k: tm[k] for k in ('n', 'accuracy', 'macro_f1', 'auroc')}
    vm = NS['val_metrics']
    p1['validation'] = {k: vm[k] for k in ('n', 'accuracy', 'macro_f1', 'auroc')}
    p1['baseline_majority'] = {k: NS['baseline_majority'][k] for k in ('accuracy', 'macro_f1')}
    bc = NS['baseline_composition']
    p1['baseline_composition'] = {k: bc[k] for k in ('rule', 'train_accuracy', 'accuracy', 'macro_f1', 'auroc')}
    p1['history'] = NS['adapt_result']['history']
    p1['trainable'] = [NS['adapt_result']['trainable_parameters'], NS['adapt_result']['total_parameters']]
    p1['new_predictions'] = [(p['id'], p['label'], round(p['score'], 4)) for p in NS['predictions']]
    p1['max_abs_score_diff'] = NS.get('max_score_diff')
    p1['splits'] = [len(NS['train_records']), len(NS['val_records']), len(NS['test_records'])]
    p1['outputs'] = sorted(p.as_posix() for p in Path('outputs').rglob('*') if p.is_file())
results['probes']['P1_default'] = p1
save()

# --- P2 stronger trivial baselines on the same split (pure Python) ----------------------------------
if 'train_records' in NS:
    tr, te = NS['train_records'], NS['test_records']
    AA = 'ACDEFGHIKLMNPQRSTVWY'
    run_fn = NS['longest_hydrophobic_run']

    def comp(seq):
        return [seq.count(a) / len(seq) for a in AA]

    # (a) longest hydrophobic run threshold, fitted on train (an order-aware one-line heuristic the notebook defines)
    best = max(((sum((run_fn(r['sequence']) >= t) == (r['label'] == 'segment') for r in tr) / len(tr), t)
                for t in range(1, 30)))
    t_run = best[1]
    acc_run = sum((run_fn(r['sequence']) >= t_run) == (r['label'] == 'segment') for r in te) / len(te)
    # (b) 20-residue composition nearest centroid (order-blind), fitted on train
    cent = {}
    for c in ('segment', 'scattered'):
        vs = [comp(r['sequence']) for r in tr if r['label'] == c]
        cent[c] = [sum(col) / len(vs) for col in zip(*vs)]

    def nc(seq):
        v = comp(seq)
        return min(cent, key=lambda c: sum((a - b) ** 2 for a, b in zip(v, cent[c])))
    acc_nc = sum(nc(r['sequence']) == r['label'] for r in te) / len(te)
    # (c) single-feature: fraction of C+H+Y (rare in the UniProt-weighted segment background, 3/13 of scattered polar draws)
    f = lambda s: sum(s.count(a) for a in 'CHY') / len(s)  # noqa: E731
    best_f = max(((sum((f(r['sequence']) >= t) == (r['label'] == 'scattered') for r in tr) / len(tr), t)
                  for t in sorted({f(r['sequence']) for r in tr})))
    acc_f = sum((f(r['sequence']) >= best_f[1]) == (r['label'] == 'scattered') for r in te) / len(te)
    mean_f = {c: round(sum(f(r['sequence']) for r in tr if r['label'] == c) / sum(r['label'] == c for r in tr), 4)
              for c in ('segment', 'scattered')}
    all_recs = NS['records']
    results['probes']['P2_baselines'] = {
        'longest_run_threshold': {'threshold': t_run, 'train_acc': round(best[0], 4), 'test_acc': acc_run},
        'composition_nearest_centroid_20aa': {'test_acc': acc_nc},
        'CHY_fraction_threshold': {'threshold': round(best_f[1], 4), 'train_acc': round(best_f[0], 4),
                                   'test_acc': acc_f, 'train_class_means': mean_f},
        'longest_run_by_class_all96': {c: [min(run_fn(r['sequence']) for r in all_recs if r['label'] == c),
                                           max(run_fn(r['sequence']) for r in all_recs if r['label'] == c)]
                                       for c in ('segment', 'scattered')},
    }
    save()

# --- P3 active learning: the documented optional experiments --------------------------------------
if p1.get('completed') == len(CODE):
    p3 = {}
    before = {
        'adapter_sha': json.loads(Path('outputs/esm2_protein_adapter/manifest.json').read_text())['files'][0]['sha256'],
        'test': p1['test'],
    }
    # (a) learner re-runs only the hyperparameter cell and the evaluation cell (no rerun instruction is given)
    ra = [run(19, {'TRAINABLE_LAYERS': 0}), run(21)]
    stale = json.loads(Path('outputs/esm2_protein_adapter/manifest.json').read_text())
    res_json = json.loads(Path('outputs/esm2_protein_result.json').read_text())
    p3['a_rerun_19_21_only'] = {
        'errors': [r['error'] for r in ra],
        'test_after': {k: NS['test_metrics'][k] for k in ('accuracy', 'macro_f1', 'auroc')},
        'trainable': [NS['adapt_result']['trainable_parameters'], NS['adapt_result']['method']],
        'history': NS['adapt_result']['history'],
        'evaluation_report_trainable_layers': json.loads(Path('outputs/esm2_protein_evaluation_report.json').read_text())['adaptation']['trainable_layers'],
        'adapter_manifest_trainable_layers_still': stale['adaptation']['trainable_layers'],
        'result_json_test_still': res_json['evaluation_report']['test_metrics']['accuracy'],
        'result_json_trainable_layers_still': res_json['evaluation_report']['adaptation']['trainable_layers'],
        'previous_test_metrics_retained_in_namespace': False,
    }
    save()
    # (b) complete rerun 19..27 with TRAINABLE_LAYERS = 0
    rb = [run(19, {'TRAINABLE_LAYERS': 0})] + [run(i) for i in (21, 23, 25, 27)]
    p3['b_head_only_full_rerun'] = {
        'errors': [r['error'] for r in rb], 'seconds': [r['seconds'] for r in rb],
        'test': {k: NS['test_metrics'][k] for k in ('accuracy', 'macro_f1', 'auroc')},
        'history': NS['adapt_result']['history'],
        'trainable': NS['adapt_result']['trainable_parameters'],
        'max_abs_score_diff': NS.get('max_score_diff'),
        'new_predictions': [(p['id'], p['label'], round(p['score'], 4)) for p in NS['predictions']],
    }
    save()
    # (c) EPOCHS = 1 (two layers) -- "AUROC may still be high while accuracy sits near 0.5"
    rc = [run(19, {'EPOCHS': 1, 'TRAINABLE_LAYERS': 2})] + [run(i) for i in (21, 23, 25, 27)]
    p3['c_epochs_1'] = {
        'errors': [r['error'] for r in rc],
        'test': {k: NS['test_metrics'][k] for k in ('accuracy', 'macro_f1', 'auroc')},
        'history': NS['adapt_result']['history'],
    }
    results['probes']['P3_active_learning'] = p3
    save()

# --- P4 BYOD -----------------------------------------------------------------------------------------
if p1.get('completed') == len(CODE):
    p4 = {}
    gen = NS['generate_sample_dataset']
    base = gen(seed=99, size=20)  # 10 segment + 10 scattered
    rng = random.Random(5)
    third = []
    for k in range(10):
        body = ''.join(rng.choice('DEKRNQST') for _ in range(rng.randint(60, 100)))
        third.append({'id': f'chg-{k:03d}', 'sequence': body, 'label': 'charged'})
    pos = base + third
    jsonl = '\n'.join(json.dumps(r) for r in pos).encode()
    UPLOAD.clear(); UPLOAD['my_proteins.jsonl'] = jsonl
    rp = [run(13, {'USE_BYOD': True})] + [run(i) for i in (15, 17)] + [run(19, {'EPOCHS': 4, 'TRAINABLE_LAYERS': 2})] + [run(i) for i in (21, 23, 25, 27)]
    p4['positive_3class_jsonl'] = {
        'errors': [r['error'] for r in rp], 'seconds': [r['seconds'] for r in rp],
        'data_source': NS.get('data_source'), 'classes': NS.get('CLASSES'),
        'splits': [len(NS['train_records']), len(NS['val_records']), len(NS['test_records'])],
        'baseline_cell_out': rp[2]['stdout_tail'][-400:],
        'test': {k: NS['test_metrics'][k] for k in ('n', 'accuracy', 'macro_f1', 'auroc')} if 'test_metrics' in NS else None,
        'new_source': NS.get('new_source'),
        'new_ids_in_test_split': all(r['id'] in {t['id'] for t in NS['test_records']} for r in NS['new_records']),
        'reload_diff': NS.get('max_score_diff'),
        'sample_dataset_csv_now_holds_byod': 'chg-000' in Path('outputs/esm2_protein_sample_dataset.csv').read_text(),
    }
    save()
    good_csv = 'id,sequence,label\n' + '\n'.join(f"{r['id']},{r['sequence']},{r['label']}" for r in base)
    negatives = {
        'lowercase.csv': good_csv.replace(base[0]['sequence'], base[0]['sequence'].lower()).encode(),
        'missing_label.csv': ('id,sequence\n' + '\n'.join(f"{r['id']},{r['sequence']}" for r in base)).encode(),
        'one_class.csv': ('id,sequence,label\n' + '\n'.join(f"{r['id']},{r['sequence']},x" for r in base)).encode(),
        'dup_sequence.csv': (good_csv + f"\nextra,{base[0]['sequence']},segment").encode(),
        'thin_class.csv': (good_csv + '\nz1,MKTAYIAKQRQISFVKSHFSRQLEERLGLIEVQ,rare').encode(),
        'gap_chars.csv': good_csv.replace(base[1]['sequence'], base[1]['sequence'][:10] + '-' + base[1]['sequence'][10:]).encode(),
        'fasta.fasta': ('>seq1\n' + base[0]['sequence'] + '\n').encode(),
        'utf16.csv': good_csv.encode('utf-16'),
        'too_long.csv': (good_csv + '\nlong1,' + 'A' * 1100 + ',segment').encode(),
    }
    neg = {}
    for name, payload in negatives.items():
        UPLOAD.clear(); UPLOAD[name] = payload
        r = run(13, {'USE_BYOD': True})
        neg[name] = r['error']
    p4['negatives'] = neg
    UPLOAD.clear()
    p4['empty_upload_dialog_cancelled'] = run(13, {'USE_BYOD': True})['error']
    results['probes']['P4_byod'] = p4
    save()

results['done'] = True
save()
print('done')
